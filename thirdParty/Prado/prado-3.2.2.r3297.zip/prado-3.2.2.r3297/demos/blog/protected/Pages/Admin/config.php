<?php
return array(
	'authorization' => array(
		array(
			'action' => 'allow',
			'roles' => 'admin',
		),
		array(
			'action' => 'deny',
			'users' => '*',
		),
	),
);