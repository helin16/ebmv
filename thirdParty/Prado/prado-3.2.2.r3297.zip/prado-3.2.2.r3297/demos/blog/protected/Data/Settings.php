<?php
return array(
	'SiteTitle' => 'MyBlog',
	'SiteSubtitle' => 'A Prado-driven weblog',
	'SiteOwner' => 'Prado User',
	'AdminEmail' => 'admin@example.com',
	'MultipleUser' => false,
	'AccountApproval' => false,
	'PostPerPage' => 6,
	'RecentComments' => 6,
	'PostApproval' => false,
	'ThemeName' => 'Winter'
);