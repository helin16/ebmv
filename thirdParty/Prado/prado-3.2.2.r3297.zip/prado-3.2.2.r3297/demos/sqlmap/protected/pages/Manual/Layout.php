<?php

class Layout extends TTemplateControl
{

}
