<?php
require_once '../../framework/prado.php';
$application = new TApplication();
$application->run();
