<?php

include_once '../../../tests/test_tools/functional_tests.php';

$test_cases = dirname(__FILE__)."/functional";

$tester=new PradoFunctionalTester($test_cases);
$tester->run(new SimpleReporter());

