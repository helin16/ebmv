<?php

class CategoryRecord
{
	public $ActualDuration = 0.0;
	public $Abbreviation = '';
	public $ID=0;
	public $EstimateDuration = 0.0;
	public $Name='';
	public $ProjectID=0; 	
}

