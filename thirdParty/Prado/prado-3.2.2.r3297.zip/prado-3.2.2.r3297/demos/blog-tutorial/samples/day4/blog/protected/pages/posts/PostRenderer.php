<?php

class PostRenderer extends TRepeaterItemRenderer
{
}

