<?php

class MainLayout extends TTemplateControl
{
}

