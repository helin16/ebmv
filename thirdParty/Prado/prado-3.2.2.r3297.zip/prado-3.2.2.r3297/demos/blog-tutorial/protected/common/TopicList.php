<?php

class TopicList extends TTemplateControl
{

}

