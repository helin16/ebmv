<?php
return array(
	'authorization' => array(
		array(
			'action' => 'deny',
			'pages' => 'Settings',
			'users' => '?',
		),
	),
	'pages' => array(
		'properties' => array(
			'MasterClass' => 'Application.Pages.Layout',
			'Theme' => 'White',
		),
	),
);