<?php
/**
 * Language List
 * @author $Author: weizhuo $
 * @version $Id: LanguageList.php 3189 2012-07-12 12:16:21Z ctrlaltca $
 * @package prado.examples
 */

/**
 *
 * @author $Author: weizhuo $
 * @version $Id: LanguageList.php 3189 2012-07-12 12:16:21Z ctrlaltca $
 */
class LanguageList extends TTemplateControl 
{
	
}

