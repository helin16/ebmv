<?php

// $Id: Home.php -1   $
class Home extends TPage
{
	public function buttonCallback ($sender, $param)
	{
		sleep(5);
	}
}

