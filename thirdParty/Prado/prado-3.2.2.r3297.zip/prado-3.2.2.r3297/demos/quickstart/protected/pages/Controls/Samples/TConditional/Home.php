<?php

class Home extends TPage
{
}

