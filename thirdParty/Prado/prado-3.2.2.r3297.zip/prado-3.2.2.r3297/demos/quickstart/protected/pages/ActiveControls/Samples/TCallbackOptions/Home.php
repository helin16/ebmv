<?php

// $Id: Home.php 3189 2012-07-12 12:16:21Z ctrlaltca $
class Home extends TPage
{
	public function buttonCallback ($sender, $param)
	{
		sleep(5);
	}
}

